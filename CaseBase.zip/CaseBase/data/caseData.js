const caseData = {
    "basic": {hits: [11, 20], drop: [1], loot: [
        {chance: 2, type: "scissors", seed: [1, 3], choice: [-3, 0]},
        {chance: 2, type: "paper", seed: [1, 2], choice: [-2, 0]},
        {chance: 2, type: "rocks", seed: [1], choice: [-1, 0]},
        {chance: 3, type: "well", seed: [1], choice: [0, 0]},
        {chance: 1, type: "rare", seed: [1], choice: [-1, 0]}
    ]},
    "rare": {hits: [21, 25], drop: [1], loot: [
        {chance: 3, type: "scissors", seed: [4], choice: [-4, 0]},
        {chance: 3, type: "paper", seed: [3], choice: [-3, 0]},
        {chance: 3, type: "rocks", seed: [2], choice: [-2, 0]},
        {chance: 1, type: "keys", seed: [1], choice: [-1, 0]}
    ]},
    "epic": {},
    "mythic": {},
    "locked": {hits: [0], drop: [1], loot: [
        {chance: 1, type: "scissors", seed: [7, 9], choice: [-9, 0]},
        {chance: 1, type: "paper", seed: [5, 6], choice: [-6, 0]},
        {chance: 1, type: "rocks", seed: [3], choice: [-3, 0]}
    ]}
}