//function definitions
const rng = (a, b) => b == undefined ? a : Math.floor(Math.random() * (Math.abs(a - b) + 1)) + Math.min(a, b);

const updateBigDiv = obj => Object.keys(obj).forEach(k => {
    let par = document.getElementById(k);
    obj[k].forEach((e, i) => {if(e != undefined){
        let [div, chn, img, lbl, ord] = [];
        if(par.children[i] == undefined){
            div = document.createElement("DIV");
            chn = div.children;
            ord = true;
            img = document.createElement("IMG");
            lbl = document.createElement("LABEL");
            div.className = "smlDiv";
            div.append(img, lbl);
            par.appendChild(div)
        } else {
            div = par.children[i];
            chn = div.children;
            ord = chn[0].tagName == "IMG";
            [img, lbl] = ord ? [chn[0], chn[1]] : [chn[1], chn[0]];
        };
        if(e[2] != undefined && e[2] != ord) div.append(div.removeChild(chn[0]));
        if(e[0] != undefined) img.src = e[0] == "" ? "" : "images/" + e[0] + ".png";
        if(e[1] != undefined) lbl.textContent = e[1];
        if(e[3] != undefined) div.id = e[3]
    }})
});
const updateSmlDiv = obj => Object.keys(obj).forEach(k => {
    let div = document.getElementById(k);
    let chn = div.children;
    let ord = chn[0].tagName == "IMG";
    let [img, lbl] = ord ? [chn[0], chn[1]] : [chn[1], chn[0]];
    if(obj[k][2] != undefined && obj[k][2] != ord) div.append(div.removeChild(chn[0]));
    if(obj[k][0] != undefined) img.src = obj[k][0] == "" ? "" : "images/" + obj[k][0] + ".png";
    if(obj[k][1] != undefined) lbl.textContent = obj[k][1];
    if(obj[k][3] != undefined) img.id = obj[k][3];
    if(obj[k][4] != undefined) lbl.id = obj[k][4]
});

const updateLbl = obj => Object.keys(obj).forEach(k => document.getElementById(k).textContent = obj[k]);

const updateImg = obj => Object.keys(obj).forEach(k => document.getElementById(k).src = obj[k] == "" ? "" : "images/" + obj[k] + ".png");

const show = (...ids) => ids.forEach(id => document.getElementById(id).classList.remove("hidden"));

const hide = (...ids) => ids.forEach(id => document.getElementById(id).classList.add("hidden"));

const clear = (...ids) => ids.forEach(id => document.getElementById(id).replaceChildren());

const destroy = (...ids) => ids.forEach(id => document.getElementById(id).remove());

const navigate = l => {
    hide(...(Array.from(document.getElementById("CaseBase").children).map(e => e.id)));
    show("bgImg", ...gameLayers[l].nodes, ...(Object.keys(gameLayers[l].btns).map(k => ({up: "navUp", dn: "navDn", lt: "navLt", rt: "navRt", fd: "navFd", bd: "navBd", cr: "centerBtn"})[k])));
    updateImg({bgImg: mainData[task][gameLayers[l].bg]});
    layer = l;
    gameLayers[l].fn?.()
};

const selectCase = t => {
    type = t;
    hits = player[t].value == 0 ? -1 : rng(...caseData[t].hits);
    drop = rng(...caseData[t].drop)
};

const selectTask = t => {
    task = t;
    taskData = questData[task]
};


//variable definitions
let player = {};
let dealer = {};

let selector = 0;
let loot = 0;
let index = 0;

let seed = 0;
let choice = 0;

let filtered = [];
let initData = [];
let dealData = {};
let dealerData = {};

let taskData = {};

let deal = {};
let looted = true;
let verified = false;

let layer = "";
let shop = false;
let taskPage = 0;
let casePage = 0;

let type = "";
let hits = 0;
let drop = 0;
let task = ""


//data definitions
let gameLayers = {
    openLayer: {bg: 1, nodes: ["cornerDiv1", "cornerDiv2", "cornerDiv3", "cornerDiv4", "centerDiv1", "centerDiv2"], btns: {
        cr: () => {
            if(hits != 0){
                hits--;
                updateLbl({hitsLbl: hits})
            } else {
                if(player[type].value != undefined) player[type].value--;
                player.casesOpened.value++;
                destroy("hitsCount");
                shop = false;
                navigate("lootLayer")
            }
        },
        up: () => {
            navigate("mainLayer")
        },
        dn: () => {
            clear("cornerDiv1", "cornerDiv2");
            updateBigDiv({
                itemColumn1: miscData.itemColumn1.map(i => [...(player[i].state ? [mainData[i][0], player[i].value] : ["item-unknown0", '?'])]),
                itemColumn2: miscData.itemColumn2.map(i => [...(player[i].state ? [mainData[i][0], player[i].value] : ["item-unknown0", '?'])]),
                itemColumn3: miscData.itemColumn3.map(i => [...(player[i].state ? [mainData[i][0], player[i].value] : ["item-unknown0", '?'])]),
                toolRow: miscData.toolRow.map(t => [mainData[i][player[i].state ? 0 : 1], ""]),
                cornerDiv1: [[mainData.casesOpened[0], player.casesOpened.value, true]],
                cornerDiv2: [[mainData.itemsLooted[0], player.itemsLooted.value, false]]
            });
            navigate("itemLayer")
        },
        lt: () => {
            clear("centerDiv1", "cornerDiv1", "cornerDiv2");
            navigate("caseLayer")
        },
        rt: () => {
            clear("centerDiv1", "cornerDiv1", "cornerDiv2");
            navigate("taskLayer")
        },
        bd: () => {
            updateImg({centerBtn: "chr-vaultkeeper0"});
            navigate("vault")
        },
        fd: () => {
            destroy("hitsCount");
            shop = true;
            navigate("lootLayer")
        }
    }, fn: () => {
        clear("centerDiv1", "centerDiv2", "cornerDiv1", "cornerDiv2", "cornerDiv3", "cornerDiv4");
        let cornerDiv1 = [];
        let cornerDiv2 = [];
        if(player[task].value){
            Object.keys(taskData.numUnlocks ?? {}).forEach(k => taskData.numUnlocks[k].forEach(l => {
                if(l > 0){
                    cornerDiv1.push([mainData[k][1], '+', true])
                } else {
                    cornerDiv2.push([mainData[k][1], '-', false])
                }
            }));
            updateBigDiv({
                cornerDiv1: [...cornerDiv1, ...(taskData.blnUnlocks ?? []).map(t => [mainData[t][0], "", true])],
                cornerDiv2: [...cornerDiv2, ...(taskData.blnLocks ?? []).map(t => [mainData[t][0], "", false])]
            })
        } else {
            Object.keys(taskData.num ?? {}).forEach(k => {if(taskData.num[k] != 0){
                cornerDiv2.push([mainData[k][0], (taskData.num[k] < 0 ? "≤" : "≥") + taskData.num[k], false]);
                cornerDiv1.push([mainData[k][0], player[k]?.value ?? (taskData.num[k] < 0 ? '∞' : "-∞"), true])
            }});
            updateBigDiv({
                cornerDiv1: [...cornerDiv1, ...(taskData.blnT ?? []).map(t => [mainData[t][player[t]?.value ?? true ? 0 : 1], "", true]), ...(taskData.blnF ?? []).map(t => [mainData[t][player[t]?.value ?? true ? 0 : 1], "", true])],
                cornerDiv2: [...cornerDiv2, ...(taskData.blnT ?? []).map(t => [mainData[t][0], "", false]), ...(taskData.blnF ?? []).map(t => [mainData[t][1], "", false])]
            });
        };
        updateBigDiv({centerDiv1: [["", hits, true, "hitsCount"]]});
        updateSmlDiv({hitsCount: [undefined, undefined, false, undefined, "hitsLbl"]});
        updateImg({centerBtn: player[type].value == 0 ? "case-unknown0": mainData[type][0]})
    }},
    lootLayer: {bg: 2, nodes: ["cornerDiv1", "cornerDiv2", "cornerDiv3", "cornerDiv4", "centerDiv1", "centerDiv2", "skip"], btns: {
        cr: () => {
            if(verified && 
                deal.pBlnTrades.filter(t => !(dealer[t]?.value ?? true)).length == 0 &&
                deal.dBlnTrades.filter(t => !(player[t]?.value ?? true)).length == 0 &&
                Object.keys(deal.numTrades).filter(k => deal.numTrades[k] < 0 ? (player[k]?.value ?? Infinity) < -deal.numTrades[k] : (dealer[k]?.value ?? Infinity) < deal.numTrades[k]).length == 0
            ){
                Object.keys(deal.numTrades).forEach(k => {
                    if(player[k] != undefined) player[k].value += deal.numTrades[k];
                    if(dealer[k] != undefined) dealer[k].value -= deal.numTrades[k];
                });
                deal.pBlnTrades.forEach(t => {
                    if(player[t] != undefined) player[t].value = true;
                    if(dealer[t] != undefined) dealer[t].value = false;
                });
                deal.dBlnTrades.forEach(t => {
                    if(player[t] != undefined) player[t].value = false;
                    if(dealer[t] != undefined) dealer[t].value = true;
                });
                if(!shop){
                    drop--;
                    looted = true
                };
                player.itemsLooted.value++;
                if(
                    Object.keys(taskData.num ?? {}).filter(k => taskData.num[k] < 0 ? -taskData.num[k] < (player[k]?.value ?? 0) : taskData.num[k] > (player[k]?.value ?? Infinity)).length == 0 &&
                    (taskData.blnT ?? []).filter(t => !(player[t]?.value ?? true)).length == 0 &&
                    (taskData.blnF ?? []).filter(t => !(player[t]?.value ?? false)).length == 0
                ){
                    Object.keys(taskData.numUnlocks ?? {}).forEach(k => taskData.numUnlocks[k].forEach(l => {if(l > 0){player[k].loot[l] = true} else {player[k].loot[-l] = false}}));
                    (taskData.blnUnlocks ?? []).forEach(t => player[t].state = true);
                    (taskData.blnLocks  ??  []).forEach(t => player[t].state = false);
                    player[task].value = true
                }
                navigate("lootLayer")
            }
        },
        up: () => {
            index++;
            navigate("lootLayer")
        },
        dn: () => {
            index--;
            navigate("lootLayer")
        },
        lt: () => {
            choice--;
            navigate("lootLayer")
        },
        rt: () => {
            choice++;
            navigate("lootLayer")
        },
        bd: () => {
            looted = true;
            navigate("openLayer")
        }
    }, fn: () => {
        if(drop != 0){
            if(looted){
                if(shop){
                    initData = {type: "shop", choice: [0, 0]};
                    seed = 0;
                    choice = 0;
                    index = 0;
                    looted = false;
                    dealer = {};
                } else {
                    filtered = caseData[type].loot.filter((e, i) => player[type].loot[i]);
                    selector = rng(1, filtered.reduce((a, v) => a + v.chance, 0));
                    let b = 0;
                    initData = filtered.reduce((a, v) => {b += v.chance; if(a == undefined && selector <= b){return v} else {return a}}, undefined);
                    seed = rng(...initData.seed);
                    choice = 0;
                    index = 0;
                    looted = false;
                    dealerData = lootData[initData.type].dealer ?? {};
                    dealer = {};
                    Object.keys(dealerData).forEach(l => {
                        dealer[l] = {};
                        dealer[l].value = typeof dealerData[l] == "object" ?
                        (dealerData[l].seed ?? 0) * seed + (dealerData[l].add ?? 0) : dealerData[l];
                    });
                }
            };
            hide(shop ? "skip" : "navBd");
            dealData = lootData[initData.type].deals[index] ?? {};
            deal = {
                pNum: {},
                dNum: {},
                numTrades: {},
                pBlnT: dealData.pBlnT ?? [],
                dBlnT: dealData.dBlnT ?? [],
                pBlnF: dealData.pBlnF ?? [],
                dBlnF: dealData.dBlnF ?? [],
                pBlnTrades: dealData.pBlnTrades ?? [],
                dBlnTrades: dealData.dBlnTrades ?? []
            };
            ["pNum", "dNum", "numTrades"].forEach(k => {
                Object.keys(dealData[k] ?? {}).forEach(l => {
                    deal[k][l] = typeof dealData[k][l] == "object" ?
                    (dealData[k][l].seed ?? 0) * seed +
                    (dealData[k][l].choice ?? 0) * choice +
                    (dealData[k][l].add ?? 0) : dealData[k][l];
                })
            });
            Object.keys(dealData.numTrades ?? {}).forEach(l => {
                if(typeof dealData.numTrades[l] == "object" && !(dealData.numTrades[l].req ?? true)) deal.numTrades[l] = deal.numTrades[l] < 0 ?
                -Math.min(-deal.numTrades[l], player[l]?.value ?? Infinity) : Math.min(deal.numTrades[l], dealer[l]?.value ?? Infinity)
            });
            verified = (
                Object.keys(deal.pNum).filter(l => deal.pNum[l] < 0 ? -deal.pNum[l] < (player[l]?.value ?? 0) : deal.pNum[l] > (player[l]?.value ?? Infinity)).length == 0 &&
                Object.keys(deal.dNum).filter(l => deal.dNum[l] < 0 ? -deal.dNum[l] < (dealer[l]?.value ?? 0) : deal.dNum[l] > (dealer[l]?.value ?? Infinity)).length == 0 &&
                deal.pBlnT.filter(t => !(player[t]?.value ?? true)).length == 0 &&
                deal.dBlnT.filter(t => !(dealer[t]?.value ?? true)).length == 0 &&
                deal.pBlnF.filter(t => (player[t]?.value ?? false)).length == 0 &&
                deal.dBlnF.filter(t => (dealer[t]?.value ?? false)).length == 0
            );
            let centerDiv1 = [];
            let centerDiv2 = [];
            let cornerDiv1 = [];
            let cornerDiv2 = [];
            let cornerDiv3 = [];
            let cornerDiv4 = [];
            clear("centerDiv1", "centerDiv2", "cornerDiv1", "cornerDiv2", "cornerDiv3", "cornerDiv4");
            if(verified){
                updateImg({centerBtn: dealData.img ?? (shop ? "" : mainData[type][1])});
                Object.keys(deal.numTrades).forEach(k => {
                    if(deal.numTrades[k] < 0){
                        centerDiv1.push([mainData[k][0], deal.numTrades[k], false]);
                        cornerDiv2.push([mainData[k][0], (player[k]?.value ?? '∞'), false])
                    } else if(deal.numTrades[k] > 0){
                        centerDiv2.push([mainData[k][0], '+' + deal.numTrades[k], false]);
                        cornerDiv1.push([mainData[k][0], (player[k]?.value ?? '∞'), true]);
                        cornerDiv4.push([mainData[k][0], (dealer[k]?.value ?? '∞'), false])
                    }
                });
                updateBigDiv({
                    centerDiv1: [...centerDiv1, ...deal.dBlnTrades.map(t => [mainData[t][1], '-', false])],
                    centerDiv2: [...centerDiv2, ...deal.pBlnTrades.map(t => [mainData[t][1], '+', false])],
                    cornerDiv1: [...cornerDiv1, ...deal.pBlnTrades.map(t => [mainData[t][(player[t]?.value ?? false) ? 0 : 1], true])],
                    cornerDiv2: [...cornerDiv2, ...deal.dBlnTrades.map(t => [mainData[t][(player[t]?.value ?? true) ? 0 : 1], false])],
                    cornerDiv3: [...cornerDiv3],
                    cornerDiv4: [...cornerDiv4, ...deal.pBlnTrades.map(t => [mainData[t][(dealer[t]?.value ?? true) ? 0 : 1], false])]
                });
            } else {
                updateImg({centerBtn: "item-unknown0"});
                Object.keys(deal.pNum).forEach(k => {if(deal.pNum[k] != 0){
                    centerDiv1.push([mainData[k][1], (deal.pNum[k] < 0 ? "≤" : "≥") + deal.pNum[k]], false);
                    cornerDiv1.push([mainData[k][1], player[k]?.value ?? (deal.pNum[k] < 0 ? '∞' : "-∞"), true])
                }});
                Object.keys(deal.dNum).forEach(k => {if(deal.dNum[k] != 0){
                    centerDiv2.push([mainData[k][1], (deal.dNum[k] < 0 ? "≤" : "≥") + deal.pNum[k]], false);
                    cornerDiv4.push([mainData[k][1], dealer[k]?.value ?? (deal.dNum[k] < 0 ? '∞' : "-∞"), false])
                }});
                updateBigDiv({
                    centerDiv1: [...centerDiv1, ...deal.pBlnT.map(t => [mainData[t][0], "", false]), ...deal.pBlnF.map(t => [mainData[t][1], "", false])],
                    centerDiv2: [...centerDiv2, ...deal.dBlnT.map(t => [mainData[t][0], "", false]), ...deal.dBlnF.map(t => [mainData[t][1], "", false])],
                    cornerDiv1: [...cornerDiv1, ...deal.pBlnT.map(t => [mainData[t][player[t]?.value ?? true ? 0 : 1], "", true]), ...deal.pBlnF.map(t => [mainData[t][player[t]?.value ?? false ? 1 : 0], "", true])],
                    cornerDiv2: [...cornerDiv2],
                    cornerDiv3: [...cornerDiv3],
                    cornerDiv4: [...cornerDiv4, ...deal.dBlnT.map(t => [mainData[t][dealer[t]?.value ?? true ? 0 : 1], "", false]), ...deal.dBlnF.map(t => [mainData[t][dealer[t]?.value ?? false ? 1 : 0], "", false])]
                })
            };
            if(choice == initData.choice[0]) hide("navLt");
            if(choice == initData.choice[1]) hide("navRt");
            if(index == lootData[initData.type].deals.length - 1) hide("navUp");
            if(index == 0) hide("navDn")
        } else {
            selectCase(type);
            navigate("openLayer")
        }
    }},
    mainLayer: {bg: 3, nodes: ["logoImg", "load", "save", "reset", "socialDiv1", "socialDiv2"], btns: {
        dn: () => navigate("openLayer")
    }, fn: () => {}},
    itemLayer: {bg: 4, nodes: ["itemColumn1", "itemColumn2", "itemColumn3", "toolRow", "cornerDiv1", "cornerDiv2"], btns: {
        up: () => navigate("openLayer")
    }, fn: () => {}},
    taskLayer: {bg: 5, nodes: ["cornerDiv2"], btns: {
        up: () => {
            taskPage++;
            navigate("taskLayer")
        },
        dn: () => {
            taskPage--;
            navigate("taskLayer")
        },
        lt: () => {
            if(player[miscData.tasks[taskPage]].state) selectTask(miscData.tasks[taskPage]);
            navigate("openLayer")
        }
    }, fn: () => {
        if(taskPage == 0) hide("navDn");
        if(taskPage == miscData.tasks.length - 1) hide("navUp");
        if(player[miscData.tasks[taskPage]].state){
            updateImg({bgImg: mainData[miscData.tasks[taskPage]][0]});
            updateBigDiv({cornerDiv2: [[player[miscData.tasks[taskPage]].value ? "img-task1" : "img-task0", "", false]]})
        } else {
            updateImg({bgImg: ""});
            updateBigDiv({cornerDiv2: [["img-task2", "", false]]})
        }
    }},
    caseLayer: {bg: 6, nodes: ["centerDiv2"], btns: {
        cr: () => {},
        up: () => {
            casePage++;
            navigate("caseLayer")
        },
        dn: () => {
            casePage--;
            navigate("caseLayer")
        },
        rt: () => {
            if(player[miscData.cases[casePage]].state) selectCase(miscData.cases[casePage]);
            navigate("openLayer")
        }
    }, fn: () => {
        if(casePage == 0) hide("navDn");
        if(casePage == miscData.cases.length - 1) hide("navUp");
        if(player[miscData.cases[casePage]].state){
            updateImg({centerBtn: mainData[miscData.cases[casePage]][0]});
            updateBigDiv({centerDiv2: [[mainData[miscData.cases[casePage]][0], player[miscData.cases[casePage]]?.value ?? '∞', false]]})
        } else {
            updateImg({centerBtn: "item-unknown0"});
            updateBigDiv({centerDiv2: [["item-unknown0", '?', false]]})
        }
    }},
    vault: {bg: 7, nodes: [], btns: {
        cr: () => (miscData.codes[prompt("What brought you here today?", "Who are you?")] ?? ["I do not seem to have that information..."]).forEach(alert),
        fd: () => navigate("openLayer")
    }, fn: () => {}}
};


//initialization
if(localStorage.caseBase == undefined) localStorage.caseBase = JSON.stringify(startData);
player = structuredClone(startData);
selectCase(miscData.cases[0]);
selectTask(miscData.tasks[0]);
navigate("mainLayer");
document.getElementById("centerBtn").addEventListener("click", () => gameLayers[layer].btns.cr?.());
document.getElementById("navUp"    ).addEventListener("click", () => gameLayers[layer].btns.up?.());
document.getElementById("navDn"    ).addEventListener("click", () => gameLayers[layer].btns.dn?.());
document.getElementById("navLt"    ).addEventListener("click", () => gameLayers[layer].btns.lt?.());
document.getElementById("navRt"    ).addEventListener("click", () => gameLayers[layer].btns.rt?.());
document.getElementById("navBd"    ).addEventListener("click", () => gameLayers[layer].btns.bd?.());
document.getElementById("navFd"    ).addEventListener("click", () => gameLayers[layer].btns.fd?.());
document.getElementById("load"     ).addEventListener("click", () => {
    player = JSON.parse(localStorage.caseBase);
    selectCase(miscData.cases[0]);
    selectTask(miscData.tasks[0])
});
document.getElementById("save"     ).addEventListener("click", () => {
    localStorage.caseBase = JSON.stringify(player)
});
document.getElementById("reset"    ).addEventListener("click", () => {
    player = structuredClone(startData);
    selectCase(miscData.cases[0]);
    selectTask(miscData.tasks[0])
});
document.getElementById("skip"     ).addEventListener("click", () => {
    looted = true;
    localStorage.caseBase = JSON.stringify(startData);
    player = structuredClone(startData);
    selectCase(miscData.cases[0]);
    selectTask(miscData.tasks[0]);
    navigate("mainLayer")
});
document.addEventListener("keydown", e => {if(e.repeat) return;
    let btn = document.getElementById(({w: "navUp", s: "navDn", a: "navLt", d: "navRt", q: "navBd", e: "navFd", ' ': "centerBtn", 1: "skip", 2: "load", 3: "save", 4: "reset"})[e.key]);
    if(btn == null || btn.classList.contains("hidden")) return;
    btn.click()
})